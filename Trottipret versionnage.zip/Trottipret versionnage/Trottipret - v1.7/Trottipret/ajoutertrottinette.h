#ifndef AJOUTERTROTTINETTE_H
#define AJOUTERTROTTINETTE_H

#include <QSql>


class AjouterTrottinette
{
public:
    AjouterTrottinette();
    void creerTrottinette();
};

#endif // AJOUTERTROTTINETTE_H
