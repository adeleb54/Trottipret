#include "ajoutertrottinette.h"

AjouterTrottinette::AjouterTrottinette()
{

}

void AjouterTrottinette::creerTrottinette(){

}
