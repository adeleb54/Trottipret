#ifndef TROTTIPRETFENPRINCIPALE_H
#define TROTTIPRETFENPRINCIPALE_H

#include <QtWidgets>

class TrottipretFenPrincipale : public QMainWindow
{
public:
    TrottipretFenPrincipale();
};

#endif // TROTTIPRETFENPRINCIPALE_H
