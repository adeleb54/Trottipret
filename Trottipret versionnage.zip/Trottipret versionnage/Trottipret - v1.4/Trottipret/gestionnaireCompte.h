#ifndef GESTIONNAIRECOMPTE_H
#define GESTIONNAIRECOMPTE_H

#include <QMainWindow>
#include <QMessageBox>
#include <QRegularExpression>
#include <string.h>
#include <iostream>
#include <QtSql>


namespace Ui {
class GestionnaireCompte;
}

/**
 * @brief La classe GestionnaireCompte
 */
class GestionnaireCompte : public QMainWindow
{
    Q_OBJECT
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    QSqlQuery query;
    int id = 0;
public:

    /**
     * @brief GestionnaireCompte::GestionnaireCompte Le constructeur de l'objet GestionnaireCompte
     * @param parent la fenêtre à ouvrir
     */
    explicit GestionnaireCompte(QWidget *parent = 0);

    /**
     * @brief GestionnaireCompte::getNom Permet d'accéder au nom qu'a entré l'utilisateur
     * @return le nom entré par l'utilisateur
     */
    QString getNom();

    /**
     * @brief GestionnaireCompte::getMdp Permet d'accéder au mot de passe qu'a entré l'utilisateur
     * @return le mot de passe entré par l'utilisateur
     */
    QString getMdp();

    /**
     * @brief GestionnaireCompte::getMdpConfirmation Permet d'accéder au mot de passe de confirmation qu'a entré l'utilisateur
     * @return le mot de passe de confirmation entré par l'utilisateur
     */
    QString getMdpConfirmation();

    /**
     * @brief GestionnaireCompte::getAdresse Permet d'accéder au mail qu'a entré l'utilisateur
     * @return le mail entré par l'utilisateur
     */
    QString getAdresse();

    /**
     * @brief GestionnaireCompte::~GestionnaireCompte Destruction de l'objet GestionnaireCompte
     */
    ~GestionnaireCompte();

private:
    Ui::GestionnaireCompte *ui;

private slots:

    /**
     * @brief GestionnaireCompte::verification Vérifie les informations envoyées par l'utilisateur
     */
    void verification();
};


#endif // GESTIONNAIRECOMPTE_H
