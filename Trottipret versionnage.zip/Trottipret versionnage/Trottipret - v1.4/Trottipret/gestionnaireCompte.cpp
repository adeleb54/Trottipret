#include "gestionnaireCompte.h"
#include "ui_gestionnaireCompte.h"

/**
 * @authors Roberge-Mentec Corentin, Vernevaut Corentin
 * Suppression de la classe Utilisateur, remplacée par la base de données
 */

using namespace std;

/**
 * @brief GestionnaireCompte::GestionnaireCompte Le constructeur de l'objet GestionnaireCompte
 * @param parent la fenêtre à ouvrir
 */
GestionnaireCompte::GestionnaireCompte(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::GestionnaireCompte){
    db.setDatabaseName("./sqlite.db");

    if(!db.open()){
        cout << "Je ne suis pas connecté à " << db.hostName().toStdString() << endl;
    }

    ui->setupUi(this);
    ui->lineEdit_mdp->setEchoMode(QLineEdit ::Password);
    ui ->lineEdit_confirmMdp->setEchoMode(QLineEdit::Password);

    QObject::connect(ui->button_valider, SIGNAL(clicked()), this, SLOT(verification()));
}

/**
 * @brief GestionnaireCompte::getNom Permet d'accéder au nom qu'a entré l'utilisateur
 * @return le nom entré par l'utilisateur
 */
QString GestionnaireCompte::getNom(){
    return ui->lineEdit_nom->text();
}

/**
 * @brief GestionnaireCompte::getMdp Permet d'accéder au mot de passe qu'a entré l'utilisateur
 * @return le mot de passe entré par l'utilisateur
 */
QString GestionnaireCompte::getMdp(){
    return ui->lineEdit_mdp->text();
}

/**
 * @brief GestionnaireCompte::getMdpConfirmation Permet d'accéder au mot de passe de confirmation qu'a entré l'utilisateur
 * @return le mot de passe de confirmation entré par l'utilisateur
 */
QString GestionnaireCompte::getMdpConfirmation(){
    return ui->lineEdit_confirmMdp->text();
}

/**
 * @brief GestionnaireCompte::getAdresse Permet d'accéder au mail qu'a entré l'utilisateur
 * @return le mail entré par l'utilisateur
 */
QString GestionnaireCompte::getAdresse(){
    return ui->lineEdit_mail->text();
}

/**
 * @brief GestionnaireCompte::verification Vérifie les informations envoyées par l'utilisateur
 */
void GestionnaireCompte::verification(){
    QMessageBox alert;
    QString nom = getNom();
    QString mdp = getMdp();
    QString mdpConfirmation = getMdpConfirmation();
    QString mail = getAdresse();

    QRegularExpression regex("^[0-9a-zA-Z]+([0-9a-zA-Z][-._+])*[0-9a-zA-Z]+@[0-9a-zA-Z]+([-.][0-9a-zA-Z]+)*([0-9a-zA-Z][.])[a-zA-Z]{2,6}$");


    if (nom.toStdString().empty() || mdp.toStdString().empty() || mdpConfirmation.toStdString().empty() || mail.toStdString().empty()){
        alert.setText("Erreur tous les champs ne sont pas rempli");
        alert.exec();
    }else if (mdp.toStdString() != mdpConfirmation.toStdString()){
        alert.setText("Erreur le mdp et le mdp de onfirmation sont différents");
        alert.exec();
    }else if(!regex.match(mail).hasMatch())
    {
        alert.setText("L'adresse mail n'est pas au bon format");
        alert.exec();
    }else{

        query.prepare("INSERT INTO Utilisateur(iduser, nom, mail, mdp, notation) VALUES (:iduser, :nom, :mail, :mdp, :notation);");
        query.bindValue(":iduser", id);
        query.bindValue(":nom", nom);
        query.bindValue(":mail", mail);
        query.bindValue(":mdp", mdp);
        query.bindValue(":notation", 5);
        query.exec();
        query.finish();
        id++;
    }
}

/**
 * @brief GestionnaireCompte::~GestionnaireCompte Destruction de l'objet GestionnaireCompte
 */
GestionnaireCompte::~GestionnaireCompte()
{
    delete ui;
}
