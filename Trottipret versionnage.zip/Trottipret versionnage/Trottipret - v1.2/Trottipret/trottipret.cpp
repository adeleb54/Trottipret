#include "trottipret.h"
#include "ui_trottipret.h"

/**
 * @authors Barbier Adèle, Roberge-Mentec Corentin
 */

/**
 * Changement dans l'affichage par rapport à la version précédente
 * @brief Trottipret::Trottipret Le constructeur de la classe
 * @param parent La fenêtre à ouvrir
 */
Trottipret::Trottipret(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Trottipret)
{
    ui->setupUi(this);
    //ui ->textMdp->setEchoMode(QLineEdit::Password);
}
/**
 * @brief Trottipret::~Trottipret Destrcution de l'objet
 */
Trottipret::~Trottipret()
{
    delete ui;
}
