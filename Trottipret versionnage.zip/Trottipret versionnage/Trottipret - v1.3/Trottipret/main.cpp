#include "gestionnaireCompte.h"
#include <QApplication>

/**
 * @author Barbier Adèle
 */

using namespace std;
/**
 * @brief main
 * @param argc
 * @param argv
 * @return l'éxecution du programme
 */
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    GestionnaireCompte gestCompte;
    gestCompte.show();

    return a.exec();
}
