#include "utilisateur.h"

/**
 * @author Vernevaut Corentin
 */

using namespace std;

long Utilisateur::idinc = 0;

/**
 * @brief Utilisateur::Utilisateur Constructeur de l'objet Utilisateur
 * @param nom de l'utilisateur
 * @param mail de l'utilisateur
 * @param mdp de l'utilisateur
 */
Utilisateur::Utilisateur(string nom, string mail, string mdp)
{
    this->nom = nom;
    this->mail = mail;
    this->mdp = mdp;
    this->idUtilisateur = idinc;
    this->idinc++;
}

/**
 * @brief Utilisateur::setIdUtilisateur permet de modifier l'id de l'utilisateur
 * @param id l'id de l'utilisateur
 */
void Utilisateur::setIdUtilisateur(int id)
{
    this->idUtilisateur = id;
}

/**
 * @brief Utilisateur::setNom permet de modifier le nom de l'utilisateur
 * @param nom le nom de l'utilisateur
 */
void Utilisateur::setNom(string nom)
{
    this->nom = nom;
}

/**
 * @brief Utilisateur::setMail permet de modifier le mail de l'utilisateur
 * @param mail le mail de l'utilisateur
 */
void Utilisateur::setMail(string mail)
{
    this->mail = mail;
}

/**
 * @brief Utilisateur::setMdp permet de modifier le mot de passe de l'utilisateur
 * @param mdp le mot de passe de l'utilisateur
 */
void Utilisateur::setMdp(string mdp)
{
    this->mdp = mdp;
}

/**
 * @brief Utilisateur::getIdUtilisateur Permet d'accéder à l'id de l'utilisateur
 * @return l'id de l'utilisateur
 */
long Utilisateur::getIdUtilisateur()
{
    return this->idUtilisateur;
}

/**
 * @brief Utilisateur::getNom Permet d'accéder au nom de l'utilisateur
 * @return le nom de l'utilisateur
 */
string Utilisateur::getNom()
{
    return this->nom;
}

/**
 * @brief Utilisateur::getMail Permet d'accéder au mail de l'utilisateur
 * @return le mail de l'utilisateur
 */
string Utilisateur::getMail()
{
    return this->mail;
}

/**
 * @brief Utilisateur::getMdp Permet d'accéder au mot de passe de l'utilisateur
 * @return le mot de passe de l'utilisateur
 */
string Utilisateur::getMdp()
{
    return this->mdp;
}

/**
 * @brief Utilisateur::toString permet d'afficher les informations de l'utilisateur
 */
void Utilisateur::toString(){
    cout << "Utilisateur numero : " + to_string(idUtilisateur) << "\n";
    cout << "   nom : " + nom << "\n";
    cout << "   mail : " + mail << endl;
}
