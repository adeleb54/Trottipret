#ifndef GESTIONNAIRECOMPTE_H
#define GESTIONNAIRECOMPTE_H

#include <QMainWindow>
#include <QMessageBox>
#include <QRegularExpression>
#include <string.h>
#include <iostream>
#include <map>
#include "utilisateur.h"

/**
 * @authors Roberge-Mentec Corentin, Vernevaut Corentin
 */

namespace Ui {
class GestionnaireCompte;
}

/**
 * @brief GestionnaireCompte::GestionnaireCompte Constructeur de la classe GestionnaireCompte
 * @param parent la fenêtre à ouvrir
 */
class GestionnaireCompte : public QMainWindow
{
    Q_OBJECT

public:
    explicit GestionnaireCompte(QWidget *parent = 0);

    /**
     * @brief GestionnaireCompte::getNom permet d'accéder au nom entré par l'utilisateur
     * @return le nom entré par l'utilisateur
     */
    std::string getNom();

    /**
     * @brief GestionnaireCompte::getMdp permet d'accéder au mot de passe entré par l'utilisateur
     * @return le mot de passe entré par l'utilisateur
     */
    std::string getMdp();

    /**
     * @brief GestionnaireCompte::getMdpConfirmation permet d'accéder au mot de passe de confirmation entré par l'utilisateur
     * @return le  mot de passe de confirmation entré par l'utilisateur
     */
    std::string getMdpConfirmation();

    /**
     * @brief GestionnaireCompte::getAdresse permet d'accéder à l'adresse mail entrée par l'utilisateur
     * @return le mail entré par l'utilisateur
     */
    std::string getAdresse();

    /**
     * @brief GestionnaireCompte::~GestionnaireCompte Destruction de l'objet GestionnaireCompte
     */
    ~GestionnaireCompte();

private:
    Ui::GestionnaireCompte *ui;
    std::map<std::string, Utilisateur*> utilisateurs;

private slots:

    /**
     * @brief GestionnaireCompte::verification permet de vérifier les informations rentées par un utilisateur
     */
    void verification();
};


#endif // GESTIONNAIRECOMPTE_H
