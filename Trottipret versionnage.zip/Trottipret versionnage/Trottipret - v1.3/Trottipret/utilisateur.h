#ifndef UTILISATEUR_H
#define UTILISATEUR_H

#include <string>
#include <iostream>

/**
 * @authors Vernevaut Corentin
 */

/**
 * @brief La classe Utilisateur
 */
class Utilisateur
{
public:
    /**
     * @brief Utilisateur Le constructeur de l'objet Utilisateur
     * @param nom de l'utilisateur
     * @param mail de l'utilisateur
     * @param mdp de l'utilisateur
     */
    Utilisateur(std::string nom, std::string mail, std::string mdp);

    /**
     * @brief Utilisateur::setIdUtilisateur permet de modifier l'id de l'utilisateur
     * @param id l'id de l'utilisateur
     */
    void setIdUtilisateur(int id);

    /**
     * @brief Utilisateur::setNom permet de modifier le nom de l'utilisateur
     * @param nom le nom de l'utilisateur
     */
    void setNom(std::string nom);

    /**
     * @brief Utilisateur::setMail permet de modifier le mail de l'utilisateur
     * @param mail le mail de l'utilisateur
     */
    void setMail(std::string mail);

    /**
     * @brief Utilisateur::setMdp permet de modifier le mot de passe de l'utilisateur
     * @param mdp le mot de passe de l'utilisateur
     */
    void setMdp(std::string mdp);

    /**
     * @brief Utilisateur::getIdUtilisateur Permet d'accéder à l'id de l'utilisateur
     * @return l'id de l'utilisateur
     */
    long getIdUtilisateur();

    /**
     * @brief Utilisateur::getNom Permet d'accéder au nom de l'utilisateur
     * @return le nom de l'utilisateur
     */
    std::string getNom();

    /**
     * @brief Utilisateur::getMail Permet d'accéder au mail de l'utilisateur
     * @return le mail de l'utilisateur
     */
    std::string getMail();

    /**
     * @brief Utilisateur::getMdp Permet d'accéder à le mot de passe de l'utilisateur
     * @return le mot de passe de l'utilisateur
     */
    std::string getMdp();

    /**
     * @brief Utilisateur::toString permet d'afficher les informations de l'utilisateur
     */
    void toString();

private :
    long idUtilisateur;
    std::string nom;
    std::string mail;
    std::string mdp;
    static long idinc;
};
#endif // UTILISATEUR_H
