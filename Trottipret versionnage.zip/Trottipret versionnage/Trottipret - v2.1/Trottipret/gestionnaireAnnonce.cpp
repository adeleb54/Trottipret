#include "gestionnaireAnnonce.h"

GestionnaireAnnonce::GestionnaireAnnonce()
{

}

void GestionnaireAnnonce::ajoutTrottinette(QString nom, QString description, QString retour, QString retrait, int taille, double prix, QDate dateDebLoca, QDate dateFinLoca, QTime heureDebLoca, QTime heureFinLoca){

}
