#ifndef INSCRIPTION_H
#define INSCRIPTION_H

#include <QDialog>
#include <QMessageBox>
#include <QRegularExpression>
#include <string.h>
#include <iostream>
#include "gestionnaireCompte.h"

/**
 * @author Barbier Adèle
 */

namespace Ui {
class Inscription;
}

/**
 * @brief La classe inscription
 */
class Inscription : public QDialog
{
    Q_OBJECT
    GestionnaireCompte gest;

public:

    /**
     * @brief Inscription Constucteur de la classe inscription
     * @param parent la fenetre à afficher
     */
    explicit Inscription(QWidget *parent = 0);

    /**
     * @brief getNom Permet d'accéder au nom entré par l'utilisateur
     * @return le nom entré par l'utilisateur
     */
    QString getNom();

    /**
     * @brief getMdp Permet d'accéder au mot de passe entré par l'utilisateur
     * @return le mot de passe entré par l'utilisateur
     */
    QString getMdp();

    /**
     * @brief getMdpConfirmation Permet d'accéder au mot de passe de confirmation entré par l'utilisateur
     * @return le mot de passe de confirmation entré par l'utilisateur
     */
    QString getMdpConfirmation();

    /**
     * @brief getAdresse Permet d'accéder au mail entré par l'utilisateur
     * @return le mail entré par l'utilisateur
     */
    QString getAdresse();

    /**
     * @brief Inscription Destruction de l'bjet Inscription
     */
    ~Inscription();

private:
    Ui::Inscription *ui;

private slots:

    /**
     * @brief verification Demande au gestionnaire de compte de vérifier les informations entrées par l'utilisateur
     */
    void verification();
};

#endif // INSCRIPTION_H
