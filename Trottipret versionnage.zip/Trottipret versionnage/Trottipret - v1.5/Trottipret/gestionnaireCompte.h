#ifndef GESTIONNAIRECOMPTE_H
#define GESTIONNAIRECOMPTE_H

#include <QMainWindow>
#include <QMessageBox>
#include <QRegularExpression>
#include <string.h>
#include <iostream>
#include <QtSql>

/**
 * @authors Roberge-Mentec Corentin, Vernevaut Corentin, Barbier Adèle
 * Suppression du lien avec l'interface, cette classe ne sert qu'à communiquer avec la base de données
 */

namespace Ui {
class GestionnaireCompte;
}

class GestionnaireCompte
{
private:
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    QSqlQuery query;
    int id = 0;
public:

    /**
     * @brief GestionnaireCompte::GestionnaireCompte Le constructeur de l'objet GestionnaireCompte
     */
    explicit GestionnaireCompte();

    /**
     * @brief verification Vérifie les informations envoyées par l'utilisateur
     */
    void verification(QString nom, QString mdp, QString mdpConfirmation, QString mail);

    /**
     * @brief ~GestionnaireCompte Destruction de l'objet GestionnaireCompte
     */
    ~GestionnaireCompte();

};


#endif // GESTIONNAIRECOMPTE_H
