#include "trottipret.h"
#include "ui_trottipret.h"

/**
 * @author Barbier Adèle
 */

/**
 * @brief Trottipret::Trottipret
 * @param parent La fenêtre à ouvrir
 */
Trottipret::Trottipret(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Trottipret)
{
    /* On ouvre la fenêtre de l'interface graphique */
    ui->setupUi(this);
}
/**
 * @brief Destruction de l'objet Trottipret
 */
Trottipret::~Trottipret()
{
    delete ui;
}
