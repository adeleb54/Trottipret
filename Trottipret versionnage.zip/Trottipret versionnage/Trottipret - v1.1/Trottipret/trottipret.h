#ifndef TROTTIPRET_H
#define TROTTIPRET_H
#include <QMainWindow>

/**
 * @author Barbier Adèle
 */
namespace Ui {
class Trottipret;
}

/**
 * @brief La classe Trottipret
 */
class Trottipret : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @brief Constructeur de la classe Trottipret
     * @param parent, la fenêtre à ouvrir
     */
    explicit Trottipret(QWidget *parent = 0);

    /**
      * @brief Destructeur de l'objet Trottipret
      */
    ~Trottipret();

private:
    /**
     * @brief Methode ouvrant l'interface graphique
     */
    Ui::Trottipret *ui;
};

#endif // TROTTIPRET_H
